
import React from 'react';
import { WP_Post } from '../types';

interface SidebarProps {
  trendingPosts: WP_Post[];
  onPostClick: (post: WP_Post) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ trendingPosts, onPostClick }) => {
  return (
    <aside className="space-y-8">
      {/* Trending Posts */}
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-lg">
        <h3 className="text-xl font-bold mb-4 border-b-2 border-blue-500 pb-2">Trending Now</h3>
        <ul className="space-y-4">
          {trendingPosts.map(post => {
            const imageUrl = post._embedded?.['wp:featuredmedia']?.[0]?.source_url || 'https://picsum.photos/100/100';
            return (
              <li key={post.id} className="flex items-start space-x-4 group cursor-pointer" onClick={() => onPostClick(post)}>
                <img src={imageUrl} alt={post.title.rendered} loading="lazy" className="w-16 h-16 object-cover rounded-md flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-sm leading-tight group-hover:text-blue-500 transition-colors" dangerouslySetInnerHTML={{ __html: post.title.rendered }}/>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{new Date(post.date).toLocaleDateString()}</p>
                </div>
              </li>
            )
          })}
        </ul>
      </div>

      {/* Ad Section */}
      <div className="bg-gray-200 dark:bg-gray-700 p-6 rounded-lg shadow-lg text-center">
        <h4 className="font-semibold text-gray-700 dark:text-gray-300">Advertisement</h4>
        <div className="bg-gray-300 dark:bg-gray-600 h-48 mt-4 rounded-md flex items-center justify-center">
          <p className="text-gray-500 dark:text-gray-400">Your Ad Here</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
